/* =========================================================
   JV IMPORTS — script.js
   - Catálogo mockado de 36 produtos
   - Filtro por categoria + busca em tempo real (index)
   - Renderização dinâmica da página de produto (produto.html)
   - Geração de link do WhatsApp com mensagem pré-preenchida
   ========================================================= */

const WHATSAPP_NUMBER = "5548996721558";

/** Define a categoria pelo intervalo do ID */
function categoryForId(id) {
  if (id <= 25) return "Perfumes Árabes";
  if (id <= 32) return "Body Splash";
  return "Outros";
}

const BENEFITS = {
  "Perfumes Árabes": ["Fixação de 12h+", "Original Importado", "Sillage marcante", "Frasco premium"],
  "Body Splash":     ["Refrescância imediata", "Hidratação prolongada", "Fragrância delicada", "Original Importado"],
  "Outros":          ["Fórmula exclusiva", "Acabamento aveludado", "Combo curado", "Original Importado"],
};

/** Lista mockada de 36 produtos — substitua nomes/descrições/imagens reais aqui */
const PRODUCTS = Array.from({ length: 36 }, (_, i) => {
  const id = i + 1;
  const category = categoryForId(id);
  return {
    id,
    name: `Produto ${id}`,
    category,
    image: `imagem${id}.jpg`,
    shortDescription: `Descrição Curta do Produto ${id}`,
    longDescription:
      `Descrição longa e envolvente do Produto ${id}. Uma composição olfativa ` +
      `cuidadosamente selecionada pela curadoria da JV Imports, pensada para quem ` +
      `busca exclusividade, presença e uma assinatura inesquecível.`,
    benefits: BENEFITS[category],
  };
});

/** Monta o link do WhatsApp com mensagem pré-preenchida */
function buildWhatsAppLink(productName) {
  const msg = `Olá, vim pelo site da JV Imports e gostaria de saber o valor e a disponibilidade do ${productName}!`;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
}

/* =========================================================
   PÁGINA INICIAL (index.html)
   ========================================================= */
function initCatalogPage() {
  const grid        = document.getElementById("productGrid");
  const emptyState  = document.getElementById("emptyState");
  const searchInput = document.getElementById("searchInput");
  const filterBtns  = document.querySelectorAll(".filter-btn");
  if (!grid) return; // não estamos na página principal

  let activeFilter = "Todos";
  let searchQuery  = "";

  function render() {
    const q = searchQuery.trim().toLowerCase();
    const list = PRODUCTS.filter((p) => {
      const matchCat    = activeFilter === "Todos" || p.category === activeFilter;
      const matchSearch = !q || p.name.toLowerCase().includes(q);
      return matchCat && matchSearch;
    });

    grid.innerHTML = list.map(cardTemplate).join("");
    emptyState.hidden = list.length > 0;
  }

  function cardTemplate(p) {
    return `
      <a class="card" href="produto.html?id=${p.id}" aria-label="Ver detalhes de ${p.name}">
        <div class="card-media">
          <img src="${p.image}" alt="${p.name}" onerror="this.style.display='none'" />
          <span class="card-watermark">JV</span>
          <span class="card-badge">${p.category}</span>
        </div>
        <div class="card-body">
          <h3 class="card-title">${p.name}</h3>
          <p class="card-desc">${p.shortDescription}</p>
          <div class="card-action">
            <span>Ver detalhes</span>
            <span class="arrow">→</span>
          </div>
        </div>
      </a>
    `;
  }

  // Filtros
  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      activeFilter = btn.dataset.filter;
      render();
    });
  });

  // Busca em tempo real
  searchInput.addEventListener("input", (e) => {
    searchQuery = e.target.value;
    render();
  });

  render();
}

/* =========================================================
   PÁGINA DE PRODUTO (produto.html)
   ========================================================= */
function initProductPage() {
  const titleEl = document.getElementById("productName");
  if (!titleEl) return; // não estamos na página de produto

  const params = new URLSearchParams(window.location.search);
  const id     = parseInt(params.get("id"), 10);
  const product = PRODUCTS.find((p) => p.id === id);

  if (!product) {
    titleEl.textContent = "Produto não encontrado";
    document.getElementById("productDescription").textContent =
      "O produto solicitado não está disponível. Volte ao catálogo para escolher outra fragrância.";
    return;
  }

  // Preenche dados
  document.title = `${product.name} — JV Imports`;
  titleEl.textContent = product.name;
  document.getElementById("productDescription").textContent = product.longDescription;
  document.getElementById("productBadge").textContent = product.category;

  const img = document.getElementById("productImage");
  img.src = product.image;
  img.alt = product.name;

  // Benefícios
  const benefitsList = document.getElementById("benefitsList");
  benefitsList.innerHTML = product.benefits.map((b) => `<li>${b}</li>`).join("");

  // Link do WhatsApp (desktop + mobile)
  const waLink = buildWhatsAppLink(product.name);
  document.getElementById("whatsappBtn").href = waLink;
  document.getElementById("whatsappBtnMobile").href = waLink;
}

/* =========================================================
   Bootstrap
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  // Ano no footer
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  initCatalogPage();
  initProductPage();
});
